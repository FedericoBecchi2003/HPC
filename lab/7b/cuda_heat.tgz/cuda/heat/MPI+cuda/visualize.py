import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from numpy import genfromtxt
a = genfromtxt('heatmap.txt', delimiter=' ')
plt.imsave('heatmap.png',a, cmap='hot')
